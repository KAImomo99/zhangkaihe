#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  exec python3 start.py
fi
printf '%s\n' '需要 Python 3。请安装后重新运行；或将 dist 部署到静态网站服务。'
read -r _answer
