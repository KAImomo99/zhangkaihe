import {test} from 'node:test';
import assert from 'node:assert/strict';
import {buildHandoff} from '../dist/workflow.js';
import {filmIdentity} from '../dist/film-library.js';
import {playbackPhotos} from '../dist/sequence.js';
test('GPT handoff preserves custom order, final captions and original source separately',()=>{const photos=[{id:'b',name:'b.jpg',story:'原始口述B',screenCaption:'最终字幕B',polishedStory:'润色B',date:'2025-06-01',stage:'相恋'},{id:'a',name:'a.jpg',story:'原始口述A',screenCaption:'最终字幕A',stage:'相识'}];const files=buildHandoff(photos,{title:'故事',settings:{seconds:4},sequence:{mode:'manual',ids:['b','a']},metadata:{version:1}});const timeline=JSON.parse(files.find(f=>f.name==='时间线.json').data);assert.deepEqual(timeline.photos.map(p=>p.id),['b','a']);assert.equal(timeline.photos[0].caption,'最终字幕B');assert.equal(timeline.photos[0].sourceStory,'原始口述B');assert.equal(timeline.narration,false);assert.match(files[0].data,/保留旧版/);assert.equal(photos[0].story,'原始口述B');});
test('finishing ordering preserves sequence while dates are annotated later',()=>{const photos=[{id:'b',date:'2025-01-01'},{id:'a',date:'2024-01-01'}],settings={mode:'manual',ids:['b','a']};photos[0].date='2020-01-01';assert.deepEqual(playbackPhotos(photos,settings).map(p=>p.id),['b','a']);});
test('film duplicate key distinguishes revisions of the same filename',()=>{assert.equal(filmIdentity('a.mp4',100,3),filmIdentity('a.mp4',100,3));assert.notEqual(filmIdentity('a.mp4',100,3),filmIdentity('a.mp4',101,3));assert.notEqual(filmIdentity('a.mp4',100,3),filmIdentity('a.mp4',100,4));});
