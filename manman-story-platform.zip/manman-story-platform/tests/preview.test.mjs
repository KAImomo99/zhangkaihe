import {test} from 'node:test';
import assert from 'node:assert/strict';
import {previewFrame,fitImage,musicLevel} from '../dist/preview-timing.js';
import {playbackPhotos} from '../dist/sequence.js';
test('rough cut uses current manual order without stories or confirmed dates, excludes skipped photos and includes new imports',()=>{
  const photos=[{id:'a',date:'',name:'a.jpg'},{id:'b',date:'2020-01-01',name:'b.jpg'},{id:'c',skip:true},{id:'d',date:'2021-01-01',name:'d.jpg'}];
  const cut=playbackPhotos(photos,{mode:'manual',ids:['b','a']});assert.deepEqual(cut.map(p=>p.id),['b','a','d']);assert.equal(previewFrame(0,cut.length,4).duration,12);assert.equal(cut[previewFrame(8,cut.length,4).index].id,'d');
});
test('crossfade starts in final 0.8 seconds and never wraps last photo',()=>{
  assert.equal(previewFrame(3,3,4).mix,0);assert.ok(Math.abs(previewFrame(3.6,3,4).mix-.5)<1e-8);
  assert.equal(previewFrame(4,3,4).index,1);assert.equal(previewFrame(4,3,4).mix,0);
  const end=previewFrame(100,3,4);assert.equal(end.index,2);assert.equal(end.next,2);assert.equal(end.mix,0);assert.equal(end.progress,1);
  assert.equal(previewFrame(-1,1,3).index,0);assert.equal(previewFrame(0,30,4).duration,120);
});
test('portraits, landscapes, and panoramas remain fully inside output at largest zoom',()=>{
  for(const [w,h] of [[3000,4000],[6000,4000],[8000,1000],[1000,8000]]){const box=fitImage(w,h,1280,720,.955);assert.ok(box.x>=0&&box.y>=0);assert.ok(box.x+box.w<=1280&&box.y+box.h<=720);assert.ok(Math.abs(box.w/box.h-w/h)<1e-9);}
});
test('music fades at film boundaries and honors mute and chosen volume',()=>{
  assert.equal(musicLevel(0,120,.35),0);assert.equal(musicLevel(120,120,.35),0);assert.equal(musicLevel(60,120,.35),.35);assert.equal(musicLevel(60,120,0),0);assert.equal(musicLevel(119,120,.4),.2);assert.equal(musicLevel(122,120,.4),0);
});
