import {test} from 'node:test';
import assert from 'node:assert/strict';
import {identifyFile,jpegName,readPhotoDate,editingFile,editingName,mediaBytes} from '../dist/media.js';
import {sequenceRows} from '../dist/sequence.js';
import {generate,scriptText} from '../dist/core.js';
const f=(name,bytes)=>new File([bytes],name);
test('detect HEIC by header despite missing or misleading extension; preserve MOV as video',async()=>{
  const heic=new Uint8Array([0,0,0,24,...new TextEncoder().encode('ftypheic0000mif1')]);
  assert.equal((await identifyFile(f('renamed.JPG',heic))).format,'HEIC');
  assert.equal((await identifyFile(f('IMG.HEIC.HEIC','broken'))).format,'HEIC');
  assert.equal((await identifyFile(f('live.MOV','\0\0\0\x18ftypqt  '))).kind,'video');
  assert.equal((await identifyFile(f('no-extension',new Uint8Array([255,216,255])))).format,'JPEG');
  assert.equal((await identifyFile(f('file.AVIF','\0\0\0\x18ftypavifmif1'))).format,'AVIF');
});
test('conversion names handle repeated extensions and original date is not replaced by conversion time',async()=>{
  assert.equal(jpegName('IMG_0931.HEIC.HEIC'),'IMG_0931.jpg');
  assert.equal(jpegName('a.HEIF'),'a.jpg');
  const info=await readPhotoDate(f('IMG_20230102_143500.HEIC','broken'));
  assert.equal(info.date,'2023-01-02T14:35:00');assert.equal(info.confirmed,false);
  assert.equal((await readPhotoDate(f('unknown.HEIC','broken'))).date,'');
});
test('editing exports use JPG but original file identity is preserved',()=>{
  const original=new Blob(['HEIC']),preview=new Blob(['JPEG']);
  const p={id:'a',name:'a.HEIC',file:original,previewFile:preview,editName:'a.jpg',date:'2020-01-01',confirmed:true,stage:'相识',story:'见面了。'};
  assert.equal(editingFile(p),preview);assert.equal(editingName(p),'a.jpg');assert.equal(mediaBytes(p),8);
  assert.equal(sequenceRows([p])[0].exportName,'0001_a.jpg');
  assert.match(scriptText(generate([p])),/剪辑素材：0001_a.jpg/);
  assert.equal(p.file,original);
  const legacy={...p,previewFile:undefined,editName:undefined};assert.equal(editingFile(legacy),original);
});
