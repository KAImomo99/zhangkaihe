import {test} from 'node:test';
import assert from 'node:assert/strict';
import {droppedIds,sequenceRows} from '../dist/sequence.js';
import {dropTarget} from '../dist/sequence-drag.js';
const photos=['a','b','c','d'].map((id,i)=>({id,name:id+'.jpg',date:`2020-01-0${i+1}`,confirmed:true,story:'故事',stage:'相识'}));
test('drop before and after works both forward and backward without off-by-one',()=>{
  assert.deepEqual(droppedIds(photos,{},'a','c','after'),['b','c','a','d']);
  assert.deepEqual(droppedIds(photos,{},'a','c','before'),['b','a','c','d']);
  assert.deepEqual(droppedIds(photos,{},'d','a','before'),['d','a','b','c']);
  assert.deepEqual(droppedIds(photos,{},'d','a','after'),['a','d','b','c']);
  assert.deepEqual(droppedIds(photos,{},'a','a','after'),['a','b','c','d']);
  assert.deepEqual(droppedIds(photos,{},'a','b','before'),['a','b','c','d']);
});
test('drop validates targets, excludes skipped photos, and preserves data',()=>{
  const snapshot=JSON.stringify(photos),items=[...photos,{id:'skip',date:'2019-01-01',name:'skip.jpg',skip:true}];
  assert.throws(()=>droppedIds(items,{},'a','skip','before'));
  assert.throws(()=>droppedIds(items,{},'missing','a','after'));
  assert.throws(()=>droppedIds(items,{},'a','b','middle'));
  assert.equal(JSON.stringify(photos),snapshot);
  const ids=droppedIds(items,{mode:'manual',ids:['d','c','b','a']},'a','d','before');
  assert.deepEqual(ids,['a','d','c','b']);
  assert.deepEqual(sequenceRows(items,{mode:'manual',ids}).map(r=>r.exportName),['0001_a.jpg','0002_d.jpg','0003_c.jpg','0004_b.jpg']);
});
test('grid hit testing supports rows, gaps, mobile column and outside cancellation',()=>{
  const cards=[{id:'a',rect:{left:0,right:100,top:0,bottom:100}},{id:'b',rect:{left:120,right:220,top:0,bottom:100}},{id:'c',rect:{left:0,right:100,top:120,bottom:220}}],bounds={left:0,right:220,top:0,bottom:220};
  assert.deepEqual(dropTarget(cards,{x:140,y:50},bounds),{id:'b',side:'before',vertical:false});
  assert.deepEqual(dropTarget(cards,{x:210,y:50},bounds),{id:'b',side:'after',vertical:false});
  assert.equal(dropTarget(cards,{x:110,y:50},bounds).id,'a');
  assert.equal(dropTarget(cards,{x:230,y:50},bounds),null);
  const column=[cards[0],cards[2]];
  assert.deepEqual(dropTarget(column,{x:50,y:130},bounds),{id:'c',side:'before',vertical:true});
  assert.deepEqual(dropTarget(column,{x:50,y:210},bounds),{id:'c',side:'after',vertical:true});
});
test('a partially filled last grid row still inserts left/right',()=>{
  const cards=[{id:'a',rect:{left:0,right:100,top:0,bottom:100}},{id:'b',rect:{left:120,right:220,top:0,bottom:100}},{id:'c',rect:{left:0,right:100,top:120,bottom:220}}];
  assert.deepEqual(dropTarget(cards,{x:20,y:200},{left:0,right:220,top:0,bottom:220}),{id:'c',side:'before',vertical:false});
});
